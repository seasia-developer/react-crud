module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      maxHeight: {
        '440px': '440px',
        '600px': '600px',
      }
    },
  },
  plugins: [],
}